// Your tasks:
// 1. Find the parent element of a cat and log it to the console.

let catElement = document.querySelector('#animalFamilyTree li:nth-child(2)');
let parentList = catElement.parentNode;
console.log('Parent of Cat:', parentList);

// 2. List all the children of the cat’s parent and log them.

let catsParent = catElement.parentNode;
Array.from(catsParent.children).forEach(child => {
    console.log('Child of the Cat\'s Parent:', child.textContent);
})

// 3. Identify the cat’s parent's next sibling in the tree and log it.

let catsParentSibling = catsParent.nextElementSibling;
console.log('Cat\'s Parent next sibling:', catsParentSibling ? catsParentSibling.textContent : 'No next sibling');