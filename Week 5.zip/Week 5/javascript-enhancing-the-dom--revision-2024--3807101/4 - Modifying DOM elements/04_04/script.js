function toggleButton() {
    let textToHighlight = document.getElementById('textToHighlight');
    textToHighlight.classList.toggle('highlight');
}
