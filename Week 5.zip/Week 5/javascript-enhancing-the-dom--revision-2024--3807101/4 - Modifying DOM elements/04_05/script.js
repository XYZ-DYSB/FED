function adjustStyle() {
    let textToStyle = document.getElementById('textToStyle');

    // Changing background color
    textToStyle.style.backgroundColor = 'yellow';

    // Changing font size
    textToStyle.style.fontSize = '20px';

    // Changing text color
    textToStyle.style.color = 'blue';

    // Adding padding
    textToStyle.style.padding = '10px';

    // Changing font weight
    textToStyle.style.fontWeight = 'bold';
}
