function updatePage() {
    let messageDiv = document.getElementById('message');
    messageDiv.innerText = 'Hello World!';

    let contentDiv = document.getElementById('content');
    contentDiv.innerHTML = '<p>Welcome to the site!</p>';
}
